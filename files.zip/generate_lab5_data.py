#!/usr/bin/env python3
"""
================================================================================
LAB 5 - SYNTHETIC P-V DATA GENERATOR
================================================================================

The assignment supplies no data, so this script manufactures three plausible
"experimental" P-V data sets at T = 300 K and writes them as CSV files.  The
analysis script (lab5_curvefit.py) then reads them BLIND - it never imports
this file and never reads the truth key - so the identification in Q1 is a
genuine test rather than a look-up.

DESIGN CHOICES (and why they matter)
------------------------------------
1.  Which gases?
        A : van der Waals, b = 0.1000 L/mol
        B : ideal
        C : van der Waals, b = 0.1500 L/mol
    One ideal and two real, with b values differing by 50 %, so that the
    excluded-volume determination in Q2 can be checked twice, independently.

2.  Why these b values and not, say, b = 0.04?
    The problem fixes a = 8.0 L^2 atm/mol^2.  The van der Waals critical
    temperature is

        Tc = 8a / (27 R b)

    With a = 8.0, small b gives a LARGE Tc:  b = 0.04 -> Tc = 722 K.  At
    T = 300 K such a gas is deeply SUBcritical, P(V) develops the van der
    Waals loop, and the isotherm passes through a two-phase region where a
    single-phase P-V data set is not physically meaningful.  Choosing

        b = 0.1000  ->  Tc = 288.9 K   (T/Tc = 1.04, supercritical)
        b = 0.1500  ->  Tc = 192.6 K   (T/Tc = 1.56, supercritical)

    keeps both gases above their critical points, so P(V) is smooth, strictly
    decreasing and single-valued over the whole sampled range.  The script
    asserts this rather than assuming it.

3.  Volume range 0.8 - 12 L, logarithmically spaced.
    Deviation from ideality scales roughly as 1/V, so log spacing puts points
    where the physics is: the deviation runs from about -26 % at V = 0.8 L to
    -2 % at V = 12 L.  A linear grid would waste most points in the region
    where all three data sets look identical.

4.  Noise: Gaussian, 0.8 % relative on P.
    Relative rather than absolute because pressure gauges quote a percentage
    of reading, and P spans more than a decade here.  Each file carries its
    own sigma_P column so that a proper chi-squared can be formed in Q4.

Run:  python3 generate_lab5_data.py
================================================================================
"""

import numpy as np

# ---- given constants (from the question) -------------------------------------
R    = 0.082057      # L atm mol^-1 K^-1
T    = 300.0         # K
NMOL = 1.0           # mol
A_VDW = 8.0          # L^2 atm mol^-2   (given)

NRT = NMOL * R * T   # 24.6171 L atm

# ---- generator settings ------------------------------------------------------
V_MIN, V_MAX, N_PTS = 0.8, 12.0, 20
SIGMA_REL = 0.008          # 0.8 % relative noise on P
SEED = 20260941           # fixed so the data set is reproducible (see README)

# ---- the three gases (this mapping is the ANSWER; kept out of the CSVs) ------
TRUTH = {
    "A": dict(kind="vdW",   b=0.1000),
    "B": dict(kind="ideal", b=None),
    "C": dict(kind="vdW",   b=0.1500),
}


def P_ideal(V, n=NMOL):
    """Ideal gas law solved for pressure:  P = nRT / V."""
    return n * R * T / np.asarray(V, float)


def P_vdw(V, b, n=NMOL, a=A_VDW):
    r"""
    Van der Waals equation solved for pressure:

        (P + a n^2 / V^2)(V - n b) = n R T
        =>  P = nRT/(V - nb)  -  a n^2 / V^2
              \____________/    \_________/
               repulsion         attraction
               (finite size)     (intermolecular)
    """
    V = np.asarray(V, float)
    return n * R * T / (V - n * b) - a * n ** 2 / V ** 2


def critical_temperature(b, a=A_VDW):
    """Tc = 8a / (27 R b) - used to confirm we stay supercritical."""
    return 8.0 * a / (27.0 * R * b)


def check_physical(V, b):
    """
    Refuse to emit data that is not a well-behaved single-phase isotherm.

      * P must be positive throughout;
      * P must be strictly decreasing in V (no van der Waals loop);
      * V - nb must stay comfortably positive.
    """
    assert np.all(V - NMOL * b > 0.1), "volume too close to the excluded volume nb"
    P = P_vdw(V, b)
    assert np.all(P > 0), "negative pressure generated"
    assert np.all(np.diff(P) < 0), "P(V) is non-monotonic - van der Waals loop present"
    return True


def main():
    rng = np.random.default_rng(SEED)

    # Common volume grid, log-spaced, rounded to look like set-point readings.
    V = np.round(np.logspace(np.log10(V_MIN), np.log10(V_MAX), N_PTS), 3)

    print("=" * 78)
    print("LAB 5 - GENERATING SYNTHETIC P-V DATA AT T = 300 K")
    print("=" * 78)
    print(f"  n = {NMOL} mol,  R = {R} L atm/mol/K,  T = {T} K  ->  nRT = {NRT:.4f} L atm")
    print(f"  a = {A_VDW} L^2 atm/mol^2 (given)")
    print(f"  {N_PTS} volumes, log-spaced over [{V_MIN}, {V_MAX}] L")
    print(f"  noise: Gaussian, {100*SIGMA_REL:.1f} % relative on P,  seed = {SEED}")

    key_lines = ["# LAB 5 - TRUTH KEY (do NOT feed this to the analysis script)",
                 "# generated by generate_lab5_data.py, seed = %d" % SEED, ""]

    for name, spec in TRUTH.items():
        if spec["kind"] == "ideal":
            P_true = P_ideal(V)
            desc = "ideal gas          PV = nRT"
            extra = ""
        else:
            b = spec["b"]
            check_physical(V, b)
            P_true = P_vdw(V, b)
            Tc = critical_temperature(b)
            desc = f"van der Waals gas   b = {b:.4f} L/mol"
            extra = f"   Tc = {Tc:.1f} K,  T/Tc = {T/Tc:.2f} (supercritical)"

        # measurement: true pressure plus relative Gaussian noise
        P_meas = P_true * (1.0 + SIGMA_REL * rng.standard_normal(V.size))
        sigma_P = SIGMA_REL * P_meas          # quoted instrument precision

        P_meas = np.round(P_meas, 4)
        sigma_P = np.round(sigma_P, 4)

        fname = f"dataset_{name}.csv"
        with open(fname, "w") as f:
            f.write("# Lab 5 - experimental P-V data\n")
            f.write(f"# gas: UNKNOWN (dataset {name})\n")
            f.write(f"# T = {T} K, n = {NMOL} mol\n")
            f.write("V_L,P_atm,sigma_P_atm\n")
            for v, p, s in zip(V, P_meas, sigma_P):
                f.write(f"{v:.3f},{p:.4f},{s:.4f}\n")

        dev = 100 * (P_true - P_ideal(V)) / P_ideal(V)
        print(f"\n  dataset_{name}.csv : {desc}{extra}")
        print(f"      P range      : {P_meas.min():.3f} - {P_meas.max():.3f} atm")
        print(f"      deviation from ideal : {dev.min():+.2f} % (V={V[np.argmin(dev)]:.2f} L) "
              f"to {dev.max():+.2f} % (V={V[np.argmax(dev)]:.2f} L)")

        key_lines.append(f"dataset_{name}.csv : {desc}{extra}")

    key_lines += ["",
                  "Expected results from the analysis:",
                  "  Q1  dataset_B is ideal; datasets A and C are real (van der Waals).",
                  "  Q2  b(A) = 0.1000 L/mol,  b(C) = 0.1500 L/mol.",
                  "  Q2  the vdW fit intercept should recover nRT = %.4f L atm." % NRT,
                  "  Q4  reduced chi-squared ~ 1 for the correct model, >> 1 for the wrong one.",
                  ]
    with open("_truth_key.txt", "w") as f:
        f.write("\n".join(key_lines) + "\n")

    print("\n  Truth key written to _truth_key.txt "
          "(for your own checking - the analysis never reads it).")
    print("=" * 78)


if __name__ == "__main__":
    main()
