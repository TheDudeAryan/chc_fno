#!/usr/bin/env python3
"""
================================================================================
LAB 5 - CURVE FITTING
Least squares fitting to distinguish ideal from real (van der Waals) gases
================================================================================

PROBLEM
-------
Three P-V data sets at T = 300 K, identities unknown.  An ideal gas obeys

        P V = n R T

a real gas the van der Waals equation

        (P + a n^2 / V^2)(V - n b) = n R T

with n = 1 mol, T = 300 K, R = 0.082057 L atm/mol/K and a = 8.0 L^2 atm/mol^2
all GIVEN.  The only unknown parameter of the real-gas model is the excluded
volume b.

MAP OF THE ASSIGNMENT ONTO THIS FILE
------------------------------------
  Q1  question_1_identify()        "Use least squares fitting to determine which
                                    datasets represent ideal and real gas
                                    behavior."

  Q2  question_2_excluded_volume() "For the real gas, determine the excluded
                                    volume b."

  Q3  question_3_compare()         "Compare the fitted models with the
                                    experimental data."

  Q4  question_4_goodness()        "Determine the goodness of each fit and
                                    justify your identification."

  Q5  question_5_physics()         "Discuss the physical origin of the deviation
                                    from ideal gas behavior."

 NOTE verification()               "Built-in fitting functions may be used only
                                    for verification."  Every numpy/scipy fitting
                                    call is confined to this one function.

SECTION 0 holds the constants, the file reader, the hand-written least-squares
routines and the goodness-of-fit statistics.  Nothing in Q1-Q5 calls a library
fitting routine.

Run:  python3 generate_lab5_data.py     (once, to create the CSV files)
      python3 lab5_curvefit.py
================================================================================
"""

import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# ==============================================================================
# SECTION 0 - CONSTANTS, DATA I/O, LEAST SQUARES, STATISTICS
# ==============================================================================

# ---- 0.1  given constants ----------------------------------------------------
R     = 0.082057      # L atm mol^-1 K^-1
T     = 300.0         # K
NMOL  = 1.0           # mol
A_VDW = 8.0           # L^2 atm mol^-2   (given, NOT fitted)

NRT = NMOL * R * T    # 24.6171 L atm - the expected value of PV for an ideal gas

DATASETS = ("A", "B", "C")

# Reject the ideal-gas model when its reduced chi-squared exceeds this value.
# For nu = 19 degrees of freedom the 99.9 % critical value of chi^2 is 43.82,
# i.e. chi^2_nu = 2.31, so anything above ~2.3 is inconsistent with the model
# at the 0.1 % level.
CHI2NU_REJECT = 2.31


# ---- 0.2  data input ---------------------------------------------------------
def load_dataset(name):
    """
    Read dataset_<name>.csv -> (V, P, sigma_P).

    The file carries a quoted pressure uncertainty per point, which is what
    makes a genuine chi-squared possible in Q4.  Comment lines start with '#'.
    """
    path = f"dataset_{name}.csv"
    if not os.path.exists(path):
        raise FileNotFoundError(f"{path} not found - run generate_lab5_data.py first")
    rows = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("V_L"):
                continue
            rows.append([float(t) for t in line.split(",")])
    arr = np.array(rows, dtype=float)
    return arr[:, 0], arr[:, 1], arr[:, 2]


# ---- 0.3  physical models ----------------------------------------------------
def P_ideal_model(V, C):
    """Ideal-gas pressure with a single fitted constant C (expected: C = nRT)."""
    return C / np.asarray(V, float)


def P_vdw_model(V, b, n=NMOL, a=A_VDW):
    r"""
    Van der Waals pressure:

        P = nRT/(V - nb)  -  a n^2 / V^2
            \___________/    \_________/
             repulsive        attractive
    """
    V = np.asarray(V, float)
    return n * R * T / (V - n * b) - a * n ** 2 / V ** 2


def corrected_pressure(V, P, n=NMOL, a=A_VDW):
    """
    P* = P + a n^2 / V^2, the 'internal-pressure-corrected' pressure used to
    linearise the van der Waals equation (see question_2_excluded_volume).
    """
    return np.asarray(P, float) + a * n ** 2 / np.asarray(V, float) ** 2


# ---- 0.4  HAND-WRITTEN LEAST SQUARES -----------------------------------------
# The assignment requires the least-squares method to be implemented directly.
# Both routines below solve the weighted normal equations in closed form; the
# weights are w_i = 1/sigma_i^2, so minimising S = sum w_i (y_i - f_i)^2 is
# exactly chi-squared minimisation.

def lsq_proportional(x, y, sigma=None):
    """
    ONE-PARAMETER fit through the origin:   y = m x

    Minimise  S(m) = sum w_i (y_i - m x_i)^2 .
        dS/dm = -2 sum w_i x_i (y_i - m x_i) = 0
        =>  m = sum(w x y) / sum(w x^2)
        =>  var(m) = 1 / sum(w x^2)

    Used for the ideal-gas model, where y = P and x = 1/V so that m = nRT.
    """
    x = np.asarray(x, float); y = np.asarray(y, float)
    w = np.ones_like(x) if sigma is None else 1.0 / np.asarray(sigma, float) ** 2
    Sxx = np.sum(w * x * x)
    Sxy = np.sum(w * x * y)
    m = Sxy / Sxx
    return m, np.sqrt(1.0 / Sxx)


def lsq_linear(x, y, sigma=None):
    """
    TWO-PARAMETER straight-line fit:   y = m x + c

    Minimising S = sum w_i (y_i - m x_i - c)^2 gives the normal equations

        c * S    + m * Sx   = Sy
        c * Sx   + m * Sxx  = Sxy      with  S=sum w, Sx=sum w x, etc.

    whose 2x2 solution is written out explicitly below.  Delta is the
    determinant; it also supplies the parameter variances.

        m = (S Sxy - Sx Sy) / Delta          var(m) = S   / Delta
        c = (Sxx Sy - Sx Sxy) / Delta        var(c) = Sxx / Delta
        cov(m, c) = -Sx / Delta

    Returns (m, c, sigma_m, sigma_c, cov_mc).
    """
    x = np.asarray(x, float); y = np.asarray(y, float)
    w = np.ones_like(x) if sigma is None else 1.0 / np.asarray(sigma, float) ** 2

    S   = np.sum(w)
    Sx  = np.sum(w * x)
    Sy  = np.sum(w * y)
    Sxx = np.sum(w * x * x)
    Sxy = np.sum(w * x * y)

    Delta = S * Sxx - Sx * Sx
    if abs(Delta) < 1e-30:
        raise ZeroDivisionError("normal equations are singular - degenerate x data")

    m = (S * Sxy - Sx * Sy) / Delta
    c = (Sxx * Sy - Sx * Sxy) / Delta
    return m, c, np.sqrt(S / Delta), np.sqrt(Sxx / Delta), -Sx / Delta


def golden_section_min(func, lo, hi, tol=1e-12, itmax=200):
    """
    Golden-section search for the minimum of a unimodal function on [lo, hi].

    Used for the DIRECT (non-linearised) van der Waals fit, where the residual
    sum S(b) is non-linear in b.  Golden section needs no derivatives and
    cannot diverge, which matters because P_vdw blows up as V -> nb.

    Each iteration keeps the bracket and discards a fraction 1 - 1/phi of it,
    so the interval shrinks geometrically by 0.618 per evaluation.
    """
    invphi = (np.sqrt(5.0) - 1.0) / 2.0           # 0.6180339887...
    a, b = lo, hi
    c, d = b - invphi * (b - a), a + invphi * (b - a)
    fc, fd = func(c), func(d)
    for _ in range(itmax):
        if b - a < tol:
            break
        if fc < fd:
            b, d, fd = d, c, fc
            c = b - invphi * (b - a)
            fc = func(c)
        else:
            a, c, fc = c, d, fd
            d = a + invphi * (b - a)
            fd = func(d)
    return 0.5 * (a + b)


# ---- 0.5  goodness-of-fit statistics -----------------------------------------
def fit_statistics(y, yfit, sigma, n_params):
    """
    The four numbers used to judge every fit in Q4.

      R^2       = 1 - SS_res/SS_tot.  Familiar, but a WEAK test here: P varies
                  by a decade, so even a badly wrong model scores R^2 > 0.99.
      RMSE      = sqrt(SS_res/N), in atm - has physical units, easy to compare
                  against the measurement precision.
      chi2_nu   = (1/(N-p)) sum [(y-yfit)/sigma]^2.  THE decisive statistic:
                  approx 1 for a correct model with correct error bars,
                  >> 1 for a wrong model.
      runs test = are the residual SIGNS random, or do they come in long blocks?
                  A wrong model leaves systematic, structured residuals even if
                  they are small.  Returns a z-score; |z| > 2 means structure.
    """
    y = np.asarray(y, float); yfit = np.asarray(yfit, float)
    sigma = np.asarray(sigma, float)
    resid = y - yfit
    N = y.size
    nu = max(N - n_params, 1)

    ss_res = np.sum(resid ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    r2 = 1.0 - ss_res / ss_tot
    rmse = np.sqrt(ss_res / N)
    chi2 = np.sum((resid / sigma) ** 2)

    # --- Wald-Wolfowitz runs test on the residual signs ---------------------
    s = np.sign(resid)
    s = s[s != 0]
    n_pos = int(np.sum(s > 0)); n_neg = int(np.sum(s < 0))
    runs = 1 + int(np.sum(s[1:] != s[:-1]))
    if n_pos > 0 and n_neg > 0:
        M = s.size
        mu = 2.0 * n_pos * n_neg / M + 1.0
        var = (2.0 * n_pos * n_neg * (2.0 * n_pos * n_neg - M)) / (M * M * (M - 1.0))
        z_runs = (runs - mu) / np.sqrt(var) if var > 0 else 0.0
    else:
        z_runs, mu = 0.0, np.nan                 # all residuals one sign

    return dict(resid=resid, R2=r2, rmse=rmse, chi2=chi2, chi2nu=chi2 / nu,
                nu=nu, runs=runs, runs_expected=mu, z_runs=z_runs,
                max_abs=np.max(np.abs(resid)))


def rule(ch="-", n=78):
    return ch * n


def banner(text):
    print("\n" + rule("="))
    print(text)
    print(rule("="))


# ==============================================================================
# QUESTION 1
# "Use least squares fitting to determine which datasets represent ideal and
#  real gas behavior."
# ==============================================================================
def question_1_identify(data):
    """
    STRATEGY.

    The ideal-gas law rearranges to  P = (nRT) * (1/V), i.e. a straight line
    through the ORIGIN in the variables x = 1/V, y = P, with slope nRT.  So a
    one-parameter weighted least-squares fit

        P = C * (1/V)

    tests ideality directly.  Two things are then examined:

      (i)  is the fitted C consistent with the known nRT = 24.6171 L atm?
      (ii) is the fit statistically acceptable (reduced chi-squared near 1,
           residual signs random)?

    A real gas fails (ii) badly: its residuals are large and systematically
    curved, because P_vdW - P_ideal grows like 1/V^2 at small V.

    Classification rule: ideal if chi2_nu < CHI2NU_REJECT, else real.
    """
    banner("QUESTION 1 - IDENTIFY WHICH DATA SETS ARE IDEAL AND WHICH ARE REAL")

    print(f"\n  Ideal-gas model:  P = C (1/V),  fitted by one-parameter weighted")
    print(f"  least squares.  Expected C = nRT = {NRT:.4f} L atm.")
    print(f"  Rejection threshold: reduced chi-squared > {CHI2NU_REJECT} "
          f"(99.9 % level).\n")

    hdr = (f"  {'set':>4} {'N':>4} {'C_fit (L atm)':>16} {'C/nRT':>8} "
           f"{'chi2_nu':>11} {'R^2':>9} {'max|res| (atm)':>15} {'verdict':>9}")
    print(hdr)
    print("  " + rule("-", len(hdr) - 2))

    ideal_fits = {}
    for name in DATASETS:
        V, P, sP = data[name]
        x = 1.0 / V

        C, sigma_C = lsq_proportional(x, P, sigma=sP)
        Pfit = P_ideal_model(V, C)
        st = fit_statistics(P, Pfit, sP, n_params=1)

        verdict = "IDEAL" if st["chi2nu"] < CHI2NU_REJECT else "REAL"
        ideal_fits[name] = dict(C=C, sigma_C=sigma_C, Pfit=Pfit,
                                verdict=verdict, **st)

        print(f"  {name:>4} {V.size:4d} {C:11.4f} +-{sigma_C:5.4f} "
              f"{C/NRT:8.4f} {st['chi2nu']:11.2f} {st['R2']:9.5f} "
              f"{st['max_abs']:15.3f} {verdict:>9}")

    print("\n  Notes:")
    for name in DATASETS:
        f = ideal_fits[name]
        dev = (f["C"] - NRT) / f["sigma_C"]
        print(f"    {name}: C differs from nRT by {dev:+.1f} sigma; "
              f"residual runs z = {f['z_runs']:+.2f} "
              f"({f['runs']} runs, expected {f['runs_expected']:.1f})")

    ideal_sets = [n for n in DATASETS if ideal_fits[n]["verdict"] == "IDEAL"]
    real_sets = [n for n in DATASETS if ideal_fits[n]["verdict"] == "REAL"]
    print(f"\n  ANSWER TO Q1:  ideal -> {', '.join(ideal_sets) or 'none'}"
          f"      real (van der Waals) -> {', '.join(real_sets) or 'none'}")

    return ideal_fits, ideal_sets, real_sets


# ==============================================================================
# QUESTION 2
# "For the real gas, determine the excluded volume b."
# ==============================================================================
def question_2_excluded_volume(data, real_sets):
    """
    TWO INDEPENDENT DETERMINATIONS OF b.

    Method 1 - LINEARISATION (closed form).
        Define the corrected pressure  P* = P + a n^2 / V^2.  The van der Waals
        equation is then simply  P* (V - nb) = nRT, i.e.

            P* V = nRT + (n b) P*

        so plotting  Y = P* V  against  X = P*  must give a STRAIGHT LINE with

            slope     = n b        -> gives b directly
            intercept = nRT        -> a prediction, not a free parameter,
                                      so agreement is an independent check
                                      that the model is right.

        Caveat: X and Y are both built from the same measured P, so their
        errors are correlated - formally an errors-in-variables problem.  The
        combination that matters is Y - (nb)X = P*(V - nb), whose uncertainty
        is sigma_P |V - nb|; those weights are used, iterating once on b.

    Method 2 - DIRECT NON-LINEAR LEAST SQUARES (no linearisation, unbiased).
        Minimise, in b alone,

            S(b) = sum w_i [ P_i - nRT/(V_i - n b) + a n^2 / V_i^2 ]^2

        by golden-section search.  Uncertainty from the Delta-chi^2 = 1 rule.

    The two methods use different weightings of the same data, so agreement
    between them is meaningful.
    """
    banner("QUESTION 2 - EXCLUDED VOLUME b FOR THE REAL GAS(ES)")

    if not real_sets:
        print("\n  No data set was classified as real - nothing to do.")
        return {}

    vdw_fits = {}
    for name in real_sets:
        V, P, sP = data[name]
        Pstar = corrected_pressure(V, P)
        X, Y = Pstar, Pstar * V

        # ---- Method 1: linearised, with propagated + iterated weights -------
        b_iter = 0.0
        for _ in range(5):
            sigma_Y = sP * np.abs(V - NMOL * b_iter)     # see docstring
            slope, intercept, s_slope, s_int, _ = lsq_linear(X, Y, sigma=sigma_Y)
            b_new = slope / NMOL
            if abs(b_new - b_iter) < 1e-14:
                b_iter = b_new
                break
            b_iter = b_new
        b_lin, sb_lin = b_iter, s_slope / NMOL

        # ---- Method 2: direct non-linear least squares in b -----------------
        w = 1.0 / sP ** 2

        def S_of_b(b):
            if V.min() - NMOL * b <= 1e-6:
                return np.inf
            return float(np.sum(w * (P - P_vdw_model(V, b)) ** 2))

        b_hi = 0.95 * V.min() / NMOL
        b_dir = golden_section_min(S_of_b, 0.0, b_hi)
        chi2_min = S_of_b(b_dir)

        # Delta-chi^2 = 1 interval -> 1-sigma uncertainty on b
        step = max(1e-6, 1e-3 * b_dir)
        while S_of_b(b_dir + step) - chi2_min < 1.0 and b_dir + step < b_hi:
            step *= 1.6
        lo, hi = 0.0, step
        for _ in range(80):
            mid = 0.5 * (lo + hi)
            if S_of_b(b_dir + mid) - chi2_min < 1.0:
                lo = mid
            else:
                hi = mid
        sb_dir = 0.5 * (lo + hi)

        Pfit = P_vdw_model(V, b_dir)
        st = fit_statistics(P, Pfit, sP, n_params=1)

        vdw_fits[name] = dict(b=b_dir, sigma_b=sb_dir, b_lin=b_lin,
                              sigma_b_lin=sb_lin, intercept=intercept,
                              sigma_int=s_int, X=X, Y=Y, Pfit=Pfit, **st)

        print(f"\n  --- dataset {name} ---")
        print(f"    Method 1  linearisation  P*V = nRT + (nb) P*")
        print(f"        slope     = {slope:.6f} +- {s_slope:.6f}  ->  "
              f"b = {b_lin:.5f} +- {sb_lin:.5f} L/mol")
        print(f"        intercept = {intercept:.4f} +- {s_int:.4f} L atm"
              f"   (predicted nRT = {NRT:.4f})")
        print(f"                    deviation = "
              f"{(intercept - NRT)/s_int:+.2f} sigma  <- model consistency check")
        print(f"    Method 2  direct non-linear least squares")
        print(f"        b = {b_dir:.5f} +- {sb_dir:.5f} L/mol")
        print(f"        chi2_nu at minimum = {st['chi2nu']:.3f}  (nu = {st['nu']})")
        print(f"    Agreement between methods: "
              f"{abs(b_dir-b_lin)/np.hypot(sb_dir, sb_lin):.2f} sigma")

    print("\n  ANSWER TO Q2:")
    for name in real_sets:
        f = vdw_fits[name]
        print(f"    dataset {name}:  b = {f['b']:.4f} +- {f['sigma_b']:.4f} L/mol"
              f"   (= {1000*f['b']:.1f} cm^3/mol)")
    return vdw_fits


# ==============================================================================
# QUESTION 3
# "Compare the fitted models with the experimental data."
# ==============================================================================
def question_3_compare(data, ideal_fits, vdw_fits):
    """
    Point-by-point comparison of measurement against both fitted models, and
    the residuals that follow.  The residual COLUMN is the informative part:
    for the correct model it scatters about zero at the size of sigma_P; for
    the wrong model it is large and systematically signed.
    """
    banner("QUESTION 3 - FITTED MODELS AGAINST THE EXPERIMENTAL DATA")

    for name in DATASETS:
        V, P, sP = data[name]
        Pid = ideal_fits[name]["Pfit"]
        has_vdw = name in vdw_fits
        Pvd = vdw_fits[name]["Pfit"] if has_vdw else None

        print(f"\n  --- dataset {name} ---")
        head = (f"    {'V (L)':>8} {'P_exp':>9} {'sigma':>7} {'P_ideal':>9} "
                f"{'resid':>9} {'res/sig':>8}")
        if has_vdw:
            head += f" {'P_vdW':>9} {'resid':>9} {'res/sig':>8}"
        print(head)
        for k in range(V.size):
            row = (f"    {V[k]:8.3f} {P[k]:9.3f} {sP[k]:7.3f} {Pid[k]:9.3f} "
                   f"{P[k]-Pid[k]:+9.3f} {(P[k]-Pid[k])/sP[k]:+8.1f}")
            if has_vdw:
                row += (f" {Pvd[k]:9.3f} {P[k]-Pvd[k]:+9.3f} "
                        f"{(P[k]-Pvd[k])/sP[k]:+8.1f}")
            print(row)

        print(f"    RMSE  ideal = {ideal_fits[name]['rmse']:.4f} atm", end="")
        if has_vdw:
            print(f"   |   RMSE  vdW = {vdw_fits[name]['rmse']:.4f} atm"
                  f"   (improvement factor "
                  f"{ideal_fits[name]['rmse']/vdw_fits[name]['rmse']:.1f})")
        else:
            print("   (ideal model already adequate - no vdW fit needed)")


# ==============================================================================
# QUESTION 4
# "Determine the goodness of each fit and justify your identification."
# ==============================================================================
def question_4_goodness(data, ideal_fits, vdw_fits):
    """
    Four statistics per fit, and why each is or is not decisive:

      R^2       inflated by the wide dynamic range of P - reported, but not
                used to decide anything.
      RMSE      compared against the mean quoted precision; a good fit has
                RMSE of order sigma.
      chi2_nu   the decisive test.  approx 1 = model consistent with the data
                and its error bars; >> 1 = model wrong (or errors understated).
      runs z    detects SYSTEMATIC residual structure even when it is small.
    """
    banner("QUESTION 4 - GOODNESS OF FIT AND JUSTIFICATION")

    hdr = (f"\n  {'set':>4} {'model':>9} {'params':>7} {'R^2':>10} "
           f"{'RMSE (atm)':>12} {'<sigma>':>9} {'chi2_nu':>11} {'runs z':>9} "
           f"{'acceptable':>12}")
    print(hdr)
    print("  " + rule("-", len(hdr) - 3))

    for name in DATASETS:
        V, P, sP = data[name]
        entries = [("ideal", ideal_fits[name], 1)]
        if name in vdw_fits:
            entries.append(("van der Waals", vdw_fits[name], 1))
        for label, f, npar in entries:
            ok = "yes" if (f["chi2nu"] < CHI2NU_REJECT and abs(f["z_runs"]) < 2.5) else "NO"
            print(f"  {name:>4} {label:>9} {npar:7d} {f['R2']:10.6f} "
                  f"{f['rmse']:12.4f} {np.mean(sP):9.4f} {f['chi2nu']:11.2f} "
                  f"{f['z_runs']:+9.2f} {ok:>12}")

    print("\n  JUSTIFICATION OF THE Q1 IDENTIFICATION:")
    for name in DATASETS:
        f = ideal_fits[name]
        if f["verdict"] == "IDEAL":
            print(f"    {name}: the ideal model gives chi2_nu = {f['chi2nu']:.2f}, "
                  f"consistent with 1, and residual")
            print(f"       signs are random (runs z = {f['z_runs']:+.2f}). "
                  f"RMSE = {f['rmse']:.4f} atm is of the same size as the")
            print(f"       quoted precision {np.mean(data[name][2]):.4f} atm. "
                  f"No evidence of non-ideality: adding the van der")
            print(f"       Waals correction is not justified for this data set.")
        else:
            g = vdw_fits[name]
            print(f"    {name}: the ideal model is rejected - chi2_nu = "
                  f"{f['chi2nu']:.0f}, i.e. residuals up to")
            print(f"       {f['max_abs']/np.mean(data[name][2]):.0f} sigma. The "
                  f"residuals also form only {f['runs']} long blocks of constant")
            print(f"       sign instead of the ~{f['runs_expected']:.0f} expected from "
                  f"random scatter (runs z = {f['z_runs']:+.2f}):")
            print(f"       strongly negative at small V, positive at large V - the "
                  f"signature of a")
            print(f"       missing 1/V^2 term, not of noise.")
            print(f"       The van der Waals model with one extra parameter reduces "
                  f"chi2_nu to {g['chi2nu']:.2f}")
            print(f"       and RMSE by a factor {f['rmse']/g['rmse']:.0f}. Its "
                  f"intercept reproduces nRT to "
                  f"{abs(g['intercept']-NRT)/g['sigma_int']:.1f} sigma,")
            print(f"       which the fit was never constrained to do. "
                  f"Identification: REAL gas.")

    bad_r2 = [ideal_fits[n]["R2"] for n in DATASETS
              if ideal_fits[n]["verdict"] == "REAL"]
    if bad_r2:
        Pspan = max(data[n][1].max() / data[n][1].min() for n in DATASETS)
        print(f"\n  Note on R^2: the REJECTED ideal fits still score R^2 = "
              f"{min(bad_r2):.3f} to {max(bad_r2):.3f},")
        print(f"  despite residuals of tens of sigma.  R^2 measures the fraction of")
        print(f"  the variance in P that the model explains, and P varies by a factor")
        print(f"  of ~{Pspan:.0f} across the data, so it is nearly saturated by ANY")
        print("  monotonic decreasing curve.  R^2 is therefore reported for")
        print("  completeness but decides nothing; chi2_nu and the runs test, which")
        print("  compare the residuals against the measurement precision rather than")
        print("  against the spread of the data, carry the argument.")


# ==============================================================================
# QUESTION 5
# "Discuss the physical origin of the deviation from ideal gas behavior."
# ==============================================================================
def question_5_physics(data, ideal_fits, vdw_fits):
    """
    Quantify the two competing molecular effects behind the van der Waals
    equation, using the fitted b and the given a:

        P = nRT/(V - nb)  -  a n^2 / V^2
            repulsion         attraction

      * b (excluded volume) - molecules have finite size, so the volume
        available for motion is V - nb, not V.  This RAISES P above ideal.
      * a (cohesion) - attraction between molecules pulls those approaching
        the wall back into the bulk, LOWERING the measured P.

    Which wins is set by the Boyle temperature T_B = a/(Rb):
        T < T_B  ->  attraction dominates, Z = PV/nRT < 1
        T > T_B  ->  repulsion dominates,  Z > 1
    """
    banner("QUESTION 5 - PHYSICAL ORIGIN OF THE DEVIATION FROM IDEALITY")

    print("\n  Compressibility factor  Z = PV/(nRT):  Z = 1 is ideal.\n")
    print(f"    {'V (L)':>8}" + "".join(f"{'  Z(' + n + ')':>10}" for n in DATASETS))
    V0 = data[DATASETS[0]][0]
    for k in range(0, V0.size, 3):
        row = f"    {V0[k]:8.3f}"
        for n in DATASETS:
            V, P, _ = data[n]
            row += f"{P[k]*V[k]/NRT:10.4f}"
        print(row)

    for name in vdw_fits:
        b = vdw_fits[name]["b"]
        V, P, _ = data[name]
        T_B = A_VDW / (R * b)
        Tc = 8 * A_VDW / (27 * R * b)
        Vc = 3 * NMOL * b
        Pc = A_VDW / (27 * b ** 2)

        print(f"\n  --- dataset {name}:  b = {b:.4f} L/mol, a = {A_VDW} "
              f"L^2 atm/mol^2 (given) ---")
        print(f"    Molecular volume implied:  nb = {NMOL*b:.4f} L per mole")
        print(f"      -> per molecule {1e24*b/6.02214076e23:.3f} nm^3, i.e. an")
        print(f"         effective hard-sphere diameter of about "
              f"{2*(3*b/(16*np.pi*6.02214076e23)*1e24)**(1/3.):.3f} nm.")
        print(f"    Boyle temperature   T_B = a/(Rb) = {T_B:8.1f} K")
        print(f"    Critical constants  Tc = 8a/27Rb = {Tc:8.1f} K, "
              f"Vc = 3nb = {Vc:.3f} L, Pc = a/27b^2 = {Pc:.2f} atm")
        print(f"    Since T = {T:.0f} K << T_B = {T_B:.0f} K, ATTRACTION dominates "
              f"at every volume sampled,")
        print(f"    so Z < 1 throughout - the gas is more compressible than ideal.")

        print(f"\n    Term-by-term breakdown (atm):")
        print(f"      {'V (L)':>8} {'P_ideal':>10} {'repulsive':>11} "
              f"{'attractive':>12} {'net dev':>10} {'% of ideal':>11}")
        for k in range(0, V.size, 3):
            v = V[k]
            Pid = NRT / v
            rep = NRT / (v - NMOL * b) - NRT / v        # always > 0
            att = -A_VDW * NMOL ** 2 / v ** 2           # always < 0
            print(f"      {v:8.3f} {Pid:10.3f} {rep:+11.3f} {att:+12.3f} "
                  f"{rep+att:+10.3f} {100*(rep+att)/Pid:+11.2f}")

        rep1 = NRT / (V[0] - NMOL * b) - NRT / V[0]
        att1 = -A_VDW / V[0] ** 2
        print(f"\n    At the smallest volume ({V[0]:.2f} L) the attractive term is "
              f"{abs(att1/rep1):.1f}x the")
        print(f"    repulsive one; both grow as V falls, but attraction (~1/V^2) "
              f"outruns")
        print(f"    repulsion (~nbRT/V^2 for V >> nb) by the factor a/(RTb) = "
              f"{A_VDW/(R*T*b):.2f} = T_B/T.")

    print("\n  PHYSICAL SUMMARY:")
    print("    The ideal gas law assumes point particles with no interactions.")
    print("    Real molecules (i) occupy volume, which reduces the free volume to")
    print("    V - nb and pushes P up, and (ii) attract one another, which slows")
    print("    molecules approaching the wall and pulls P down by a n^2/V^2.  At")
    print("    300 K, well below the Boyle temperature of both fitted gases, the")
    print("    attractive term wins and the measured pressure falls below ideal by")
    print("    up to ~26 %.  The deviation vanishes as V grows because both")
    print("    corrections are relative effects of order nb/V and a/(RTV).")


# ==============================================================================
# NOTE - "Built-in fitting functions may be used only for verification."
# ==============================================================================
def verification(data, ideal_fits, vdw_fits):
    """
    Check the hand-written least squares against library routines:

        lsq_proportional / lsq_linear  vs  numpy.polyfit  (and lstsq)
        golden-section vdW fit         vs  scipy.optimize.curve_fit
    """
    banner("NOTE - VERIFICATION AGAINST BUILT-IN FITTING FUNCTIONS (checking only)")

    from scipy.optimize import curve_fit

    ok = True
    for name in DATASETS:
        V, P, sP = data[name]
        print(f"\n  dataset {name}")

        # (i) one-parameter ideal fit vs numpy least squares
        x = (1.0 / V)[:, None] / sP[:, None]
        C_np = float(np.linalg.lstsq(x, P / sP, rcond=None)[0][0])
        d1 = abs(C_np - ideal_fits[name]["C"])
        ok &= d1 < 1e-9
        print(f"      |C_hand - numpy.linalg.lstsq|            = {d1:.3e}")

        if name in vdw_fits:
            f = vdw_fits[name]
            # (ii) linearised straight-line fit vs numpy.polyfit
            sigma_Y = sP * np.abs(V - NMOL * f["b_lin"])
            m_np, c_np = np.polyfit(f["X"], f["Y"], 1, w=1.0 / sigma_Y)
            d2 = abs(m_np / NMOL - f["b_lin"])
            ok &= d2 < 1e-9
            print(f"      |b_linearised - numpy.polyfit slope|     = {d2:.3e}")

            # (iii) direct non-linear fit vs scipy.optimize.curve_fit
            popt, pcov = curve_fit(lambda v, bb: P_vdw_model(v, bb), V, P,
                                   p0=[0.05], sigma=sP, absolute_sigma=True)
            d3 = abs(popt[0] - f["b"])
            d4 = abs(np.sqrt(pcov[0, 0]) - f["sigma_b"])
            ok &= d3 < 1e-6
            print(f"      |b_direct - scipy.curve_fit|             = {d3:.3e}")
            print(f"      |sigma_b  - scipy covariance|            = {d4:.3e}")

    print(f"\n  ALL CHECKS PASSED: {ok}")
    return ok


# ==============================================================================
# FIGURES
# ==============================================================================
def make_figures(data, ideal_fits, vdw_fits):
    plt.rcParams.update({"font.size": 9.5, "axes.grid": True, "grid.alpha": 0.3,
                         "figure.dpi": 150, "savefig.dpi": 150,
                         "axes.axisbelow": True, "mathtext.fontset": "dejavusans"})
    colors = {"A": "#1f77b4", "B": "#2ca02c", "C": "#d62728"}

    # ---- Q1: isotherms + residuals from the ideal fit ------------------------
    fig, ax = plt.subplots(1, 2, figsize=(11.5, 4.2))
    Vg = np.linspace(0.75, 12.5, 400)
    ax[0].plot(Vg, NRT / Vg, "k-", lw=1.6, label="ideal  $P=nRT/V$", zorder=2)
    for n in DATASETS:
        V, P, sP = data[n]
        ax[0].errorbar(V, P, yerr=sP, fmt="o", ms=4.5, mfc="white",
                       mec=colors[n], ecolor=colors[n], mew=1.2, lw=1,
                       label=f"dataset {n}", zorder=3)
    ax[0].set_xlabel("$V$ (L)"); ax[0].set_ylabel("$P$ (atm)")
    ax[0].set_title("(a) measured isotherms at 300 K", fontsize=10, loc="left")
    ax[0].legend(fontsize=8)

    for n in DATASETS:
        V, P, sP = data[n]
        ax[1].plot(V, ideal_fits[n]["resid"] / sP, "o-", ms=4.5, color=colors[n],
                   lw=1, label=f"{n}  ($\\chi^2_\\nu$ = "
                               f"{ideal_fits[n]['chi2nu']:.1f})")
    ax[1].axhline(0, color="k", lw=0.9)
    ax[1].axhspan(-2, 2, color="grey", alpha=0.15, label=r"$\pm 2\sigma$")
    ax[1].set_xlabel("$V$ (L)"); ax[1].set_ylabel(r"residual / $\sigma_P$")
    ax[1].set_yscale("symlog", linthresh=5)
    ax[1].set_title("(b) residuals of the IDEAL fit", fontsize=10, loc="left")
    ax[1].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig("fig_q1_identify.png", bbox_inches="tight")
    plt.close(fig)

    # ---- Q2: the van der Waals linearisation --------------------------------
    fig, a = plt.subplots(figsize=(6.6, 4.4))
    for n in DATASETS:
        V, P, sP = data[n]
        Pstar = corrected_pressure(V, P)
        a.plot(Pstar, Pstar * V, "o", ms=5, mfc="white", mec=colors[n], mew=1.3,
               label=f"dataset {n}")
        if n in vdw_fits:
            xs = np.linspace(Pstar.min(), Pstar.max(), 50)
            a.plot(xs, NRT + NMOL * vdw_fits[n]["b"] * xs, "-", color=colors[n],
                   lw=1.4, label=f"   fit: $b$ = {vdw_fits[n]['b']:.4f} L/mol")
    a.axhline(NRT, ls=":", color="k", lw=1.2)
    a.text(a.get_xlim()[0] + 1, NRT + 0.25, f"intercept $= nRT = {NRT:.3f}$",
           fontsize=8)
    a.set_xlabel(r"$P^* = P + an^2/V^2$   (atm)")
    a.set_ylabel(r"$P^* V$   (L atm)")
    a.set_title("Q2: van der Waals linearisation  $P^*V = nRT + (nb)P^*$",
                fontsize=10, loc="left")
    a.legend(fontsize=8, loc="upper left")
    fig.tight_layout()
    fig.savefig("fig_q2_linearisation.png", bbox_inches="tight")
    plt.close(fig)

    # ---- Q3: fitted models vs data, per dataset ------------------------------
    fig, axes = plt.subplots(2, 3, figsize=(14, 6.4),
                             gridspec_kw={"height_ratios": [2.2, 1]})
    for j, n in enumerate(DATASETS):
        V, P, sP = data[n]
        top, bot = axes[0, j], axes[1, j]
        Vg = np.linspace(V.min() * 0.97, V.max() * 1.02, 400)

        top.errorbar(V, P, yerr=sP, fmt="o", ms=4.5, mfc="white", mec="k",
                     ecolor="k", mew=1.1, lw=1, label="data", zorder=4)
        top.plot(Vg, P_ideal_model(Vg, ideal_fits[n]["C"]), "--", color="#1f77b4",
                 lw=1.5, label="ideal fit")
        if n in vdw_fits:
            top.plot(Vg, P_vdw_model(Vg, vdw_fits[n]["b"]), "-", color="#d62728",
                     lw=1.6, label="van der Waals fit")
        top.set_ylabel("$P$ (atm)")
        top.set_title(f"dataset {n} - {ideal_fits[n]['verdict']}",
                      fontsize=10, loc="left")
        top.legend(fontsize=8)

        bot.axhline(0, color="k", lw=0.9)
        bot.axhspan(-2, 2, color="grey", alpha=0.15)
        bot.plot(V, ideal_fits[n]["resid"] / sP, "s--", ms=4, color="#1f77b4",
                 lw=1, label="ideal")
        if n in vdw_fits:
            bot.plot(V, vdw_fits[n]["resid"] / sP, "o-", ms=4, color="#d62728",
                     lw=1, label="vdW")
        bot.set_xlabel("$V$ (L)"); bot.set_ylabel(r"resid / $\sigma$")
        bot.set_yscale("symlog", linthresh=5)
        bot.legend(fontsize=7.5)
    fig.tight_layout()
    fig.savefig("fig_q3_models.png", bbox_inches="tight")
    plt.close(fig)

    # ---- Q5: compressibility factor and term breakdown -----------------------
    fig, ax = plt.subplots(1, 2, figsize=(11.5, 4.2))
    for n in DATASETS:
        V, P, sP = data[n]
        ax[0].errorbar(V, P * V / NRT, yerr=sP * V / NRT, fmt="o", ms=4.5,
                       mfc="white", mec=colors[n], ecolor=colors[n], mew=1.2,
                       lw=1, label=f"dataset {n}")
        if n in vdw_fits:
            Vg = np.linspace(V.min(), V.max(), 300)
            ax[0].plot(Vg, P_vdw_model(Vg, vdw_fits[n]["b"]) * Vg / NRT, "-",
                       color=colors[n], lw=1.3)
    ax[0].axhline(1.0, ls="--", color="k", lw=1.2)
    ax[0].text(8.5, 1.008, "ideal gas, $Z=1$", fontsize=8)
    ax[0].set_xlabel("$V$ (L)"); ax[0].set_ylabel("$Z = PV/nRT$")
    ax[0].set_title("(a) compressibility factor", fontsize=10, loc="left")
    ax[0].legend(fontsize=8, loc="lower right")

    if vdw_fits:
        n0 = sorted(vdw_fits)[0]
        b = vdw_fits[n0]["b"]
        Vg = np.linspace(0.8, 12, 400)
        rep = NRT / (Vg - NMOL * b) - NRT / Vg
        att = -A_VDW * NMOL ** 2 / Vg ** 2
        ax[1].plot(Vg, rep, "-", color="#2ca02c", lw=1.7,
                   label=r"repulsive  $nRT\left[\frac{1}{V-nb}-\frac{1}{V}\right]$")
        ax[1].plot(Vg, att, "-", color="#d62728", lw=1.7,
                   label=r"attractive  $-an^2/V^2$")
        ax[1].plot(Vg, rep + att, "-", color="k", lw=1.9, label="net deviation")
        ax[1].axhline(0, color="grey", lw=0.9)
        ax[1].set_xlabel("$V$ (L)"); ax[1].set_ylabel(r"$P-P_{\rm ideal}$ (atm)")
        ax[1].set_title(f"(b) competing terms, dataset {n0} ($b$ = {b:.4f} L/mol)",
                        fontsize=10, loc="left")
        ax[1].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig("fig_q5_physics.png", bbox_inches="tight")
    plt.close(fig)

    print("\n  Figures written:")
    for f in ("fig_q1_identify.png", "fig_q2_linearisation.png",
              "fig_q3_models.png", "fig_q5_physics.png"):
        print(f"    {f}")


# ==============================================================================
# DRIVER
# ==============================================================================
def main():
    print(rule("="))
    print("LAB 5 : CURVE FITTING - IDEAL vs REAL (VAN DER WAALS) GAS")
    print(rule("="))
    print(f"  n = {NMOL} mol,  T = {T} K,  R = {R} L atm/mol/K")
    print(f"  a = {A_VDW} L^2 atm/mol^2 (given)   ->   nRT = {NRT:.4f} L atm")

    data = {n: load_dataset(n) for n in DATASETS}
    print(f"  loaded {len(data)} data sets, "
          f"{data['A'][0].size} points each")

    ideal_fits, ideal_sets, real_sets = question_1_identify(data)       # Q1
    vdw_fits = question_2_excluded_volume(data, real_sets)              # Q2
    question_3_compare(data, ideal_fits, vdw_fits)                      # Q3
    question_4_goodness(data, ideal_fits, vdw_fits)                     # Q4
    question_5_physics(data, ideal_fits, vdw_fits)                      # Q5
    verification(data, ideal_fits, vdw_fits)                            # Note

    banner("FIGURES")
    make_figures(data, ideal_fits, vdw_fits)
    print("\n" + rule("="))
    return data, ideal_fits, vdw_fits


if __name__ == "__main__":
    main()
